class MoviesController < ApplicationController

  def movie_params
    params.require(:movie).permit(:title, :rating, :description, :release_date)
  end

  def show
    id = params[:id] # retrieve movie ID from URI route
    @movie = Movie.find(id) # look up movie by unique ID
    # will render app/views/movies/show.<extension> by default
  end

  def index
    @all_ratings = Movie.sorted_ratings
    
    # Take note of all checked ratings if one or more boxes are marked
    # If not, do not change anything
    if params[:ratings]
      @marked_ratings = params[:ratings].keys
    else
      @marked_ratings = @all_ratings
    end

    # If told to sort, make sure to keep note of by which attribute to order movies
    if params[:sort]
      @sort = params[:sort]
    else
      @sort = nil
    end
    
    # Pick movies that have the marked ratings
    # List them according to default order, title, or release date
    @movies = Movie.marked_sorted_rated_movies(@marked_ratings, @sort)
  end

  def new
    # default: render 'new' template
  end

  def create
    @movie = Movie.create!(movie_params)
    flash[:notice] = "#{@movie.title} was successfully created."
    redirect_to movies_path
  end

  def edit
    @movie = Movie.find params[:id]
  end

  def update
    @movie = Movie.find params[:id]
    @movie.update_attributes!(movie_params)
    flash[:notice] = "#{@movie.title} was successfully updated."
    redirect_to movie_path(@movie)
  end

  def destroy
    @movie = Movie.find(params[:id])
    @movie.destroy
    flash[:notice] = "Movie '#{@movie.title}' deleted."
    redirect_to movies_path
  end

end
