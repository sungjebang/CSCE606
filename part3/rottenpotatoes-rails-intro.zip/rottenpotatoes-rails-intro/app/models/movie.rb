class Movie < ActiveRecord::Base
    # attr_accessible :title, :rating, :release_date, :description
    
    # Order by attribute
    # source: https://apidock.com/rails/ActiveRecord/QueryMethods/order
    def self.movies(attr_op)
        self.order(attr_op)
    end
    
    def self.map_all_ratings
        self.all.map{|r| r.rating}
    end
    
    # Sort all ratings
    # source: https://andrewjgrimm.wordpress.com/2011/10/03/in-ruby-method-passes-you/
    # source: https://reactive.io/tips/2008/12/21/understanding-ruby-blocks-procs-and-lambdas
    def self.sorted_ratings
        self.order(:rating).select(:rating).map(&:rating).uniq
    end
    
    # Get movies with rating attribute that matches with inputted rating
    # After that, sort them according to inputted type
    # source: https://apidock.com/rails/ActiveRecord/QueryMethods/where
    # source: https://apidock.com/rails/ActiveRecord/QueryMethods/order
    def self.marked_sorted_rated_movies(rating_input, sort_type)
        self.where(:rating => rating_input).order(sort_type)
    end
end
